<html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>

		<footer class="page-footer teal darken-3">
          <div class="container">
            <div class="row">
              <div class="col l12 s12">
                <h5 class="white-text">Placement Records</h5>
                <p class="grey-text text-lighten-4">All the students can refer to the earlier placement details. Students can get the details of the companies and the procedures followed by their seniors.</p>
              </div>

            </div>
          </div>

        </footer>

    </body>
</html>

