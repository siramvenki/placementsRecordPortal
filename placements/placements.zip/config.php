<?php 
	$server="localhost";
    $u="root";
    $p="";
    $mysqli=new mysqli($server,$u,$p,"placements");
 ?>