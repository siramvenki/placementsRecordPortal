<?php
    if ($_POST) {
    	$email=$_POST['email'];
		$userName=$_POST['name'];
		$rollNo=$_POST['rollNo'];
		$password=$_POST['password'];
		$rePassword=$_POST['rePassword'];
    }
	
	$pieces = explode("IH", $rollNo);
	
	include "config.php";
	$data = $mysqli->query("SELECT * FROM user2016 WHERE email='$email'");


    if($row = $data->fetch_assoc())
    {
    	echo "failure";
    }
    else
    {
    	$confirmcode=rand();
	$mysqli->query("INSERT INTO user2016(email,name,roll,password,year,valid,confirmcode) VALUES('$email','$userName','2016','$password',2016,0,'$confirmcode')");
	$message= 
	"
	confirm your email 
	click link below to verify your account
	http://www.placements.esy.es/emailconfirm.php?email=$email&code=$confirmcode

	";
	mail($email,"confirm your email from placements portal", $message);
	echo "Registration complete please confirm your email sent to your mail account";
    }

?>