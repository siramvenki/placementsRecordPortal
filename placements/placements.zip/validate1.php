<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
	include "config.php";

	$var=$_GET['id'];
	$pieces = explode(" ", $var);
	if()

?>

</body>
</html>